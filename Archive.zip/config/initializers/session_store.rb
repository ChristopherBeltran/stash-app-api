StashAppApi::Application.config.session_store :cookie_store, key: 'stash_app_session'
